

products = [
    # Snacks
    {
        "tag": "nutella",
        "label": "Nutella Choco Spread",
        "category": "snacks",
    },
    {
        "tag": "noodles",
        "label": "Noodles(1 Pack)",
        "category": "snacks",
    },
    {
        "tag": "lays",
        "label": "Lays(10Rs)",
        "category": "snacks",
    },
    {
        "tag": "oreo",
        "label": "Oreo(20Rs)",
        "category": "snacks",
    },
    {
        "tag": "muffin",
        "label": "Chocolate Muffin",
        "category": "snacks",
    },
    {
        "tag": "silk",
        "label": "Dairy Milk Silk(60Rs)",
        "category": "snacks",
    },
    {
        "tag": "namkeen",
        "label": "Namkeen(15Rs)",
        "category": "snacks",
    },

    # Grocery
    {
        "tag": "atta",
        "label": "Ashirvaad Atta(1kg)",
        "category": "grocery",
    },
    {
        "tag": "pasta",
        "label": "Pasta(1kg)",
        "category": "grocery",
    },
    {
        "tag": "rice",
        "label": "Basmathi(1kg)",
        "category": "grocery",
    },
    {
        "tag": "oil",
        "label": "Sunflower Oil(1kg)",
        "category": "grocery",
    },
    {
        "tag": "sugar",
        "label": "Refined Sugar(1kg)",
        "category": "grocery",
    },
    {
        "tag": "dal",
        "label": "Daal(1kg)",
        "category": "grocery",
    },
    {
        "tag": "tea",
        "label": "Tea Powder(1kg)",
        "category": "grocery",
    },

    # Beauty & Hygiene
    {
        "tag": "soap",
        "label": "Bathing Soap",
        "category": "beauty",
    },
    {
        "tag": "shampoo",
        "label": "Shampoo(1ltr)",
        "category": "beauty",
    },
    {
        "tag": "lotion",
        "label": "Body Lotion(1ltr)",
        "category": "beauty",
    },
    {
        "tag": "cream",
        "label": "Face Cream",
        "category": "beauty",
    },
    {
        "tag": "foam",
        "label": "Shaving Foam",
        "category": "beauty",
    },
    {
        "tag": "mask",
        "label": "Face Mask(1 piece)",
        "category": "beauty",
    },
    {
        "tag": "sanitizer",
        "label": "Hand Sanitizer",
        "category": "beauty",
    },
]